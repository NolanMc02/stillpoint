@echo off
setlocal
cd /d "%~dp0"
if not exist "tools\audiobook\generate.py" (
  echo Put this repair file and the alignment-repair folder into your existing
  echo Stillpoint folder, beside Open Audiobook Studio.cmd, then run it again.
  pause
  exit /b 1
)
if not exist "alignment-repair\generate.py" (
  echo Extract the complete repair ZIP first. The alignment-repair folder is missing.
  pause
  exit /b 1
)
if not exist "alignment-repair\generate-before-repair.py" (
  copy /y "tools\audiobook\generate.py" "alignment-repair\generate-before-repair.py" >nul
  if errorlevel 1 (
    echo The original generator could not be backed up. Repair stopped.
    pause
    exit /b 1
  )
)
copy /y "alignment-repair\generate.py" "tools\audiobook\generate.py" >nul
if errorlevel 1 (
  echo Repair could not be copied. Keep this error for troubleshooting.
  pause
  exit /b 1
)
echo Alignment fix applied. Your books, models and saved audio were kept.
echo Open Audiobook Studio.cmd, then Resume the failed job in Your narration.
echo You do not need to run Setup again.
pause
